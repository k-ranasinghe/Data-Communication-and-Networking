// general purpose standard C lib
#include <stdio.h>
#include <stdlib.h> // stdlib includes malloc() and free()


// user-defined header files
#include "transmissionerr.h"

//Any additional function prototypes if necessary


int main()
{
    
    //Read input

    //Call relevant run function
    
    //Call any other function here

    //Free up any malloc-ed memory
	return 0;
}

void runCRC(char *sendm, char *poly, char **recvm) 
{
	//TODO
}

void runHammingCode(char *sendm, int parity, char **recvm) 
{
    //TODO
}


